package wolox.training.controllers;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import wolox.training.exceptions.UserNotFoundException;
import wolox.training.models.Book;
import wolox.training.models.User;
import wolox.training.repositories.BookRepository;
import wolox.training.repositories.UserRepository;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static net.bytebuddy.matcher.ElementMatchers.is;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(BookController.class)
class BookControllerTest {

    @Mock
    private BookRepository bookRepository;

    @Autowired
    private MockMvc mvc;

    @MockBean
    private BookController bookController;

    @Test
    public void findAllTest() throws Exception {
        Book book = new Book();
        book.setTitle("Test name");

        List<Book> allBooks= Arrays.asList(book);

        when(bookController.findAll()).thenReturn(allBooks);

        mvc.perform(get("/api/books")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("$", hasSize(1)))
                .andExpect((ResultMatcher) jsonPath("$[0].name", is(book.getTitle())));
    }

    @Test
    public void findByUsernameTest() throws Exception{
        Book book = new Book();
        book.setTitle("Test Name");
        book.setId(89L);
        List<Book> allBooks = Arrays.asList(book);

        when(bookRepository.findByAuthor(book.getAuthor())).thenReturn((allBooks));

        mvc.perform(get("/api/books/" + book.getAuthor())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("name", is(book.getTitle())));
    }

    @Test
    public void findOneTest() throws Exception {
        Book book = new Book();
        book.setTitle("Test Name");
        book.setId(89L);

        when(bookRepository.findById(book.getId())).thenReturn(Optional.of(book));

        mvc.perform(get("/api/books/" + book.getId().toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect((ResultMatcher) jsonPath("name", is(book.getTitle())));
    }

    @Test
    public void should_throw_exception_when_user_doesnt_exist_when_findById() throws Exception {
        Book book = new Book();
        book.setId(89L);
        book.setTitle("Test Name");

        Mockito.doThrow(new UserNotFoundException()).when(bookRepository).findById(book.getId());

        mvc.perform(get("/api/books/" + book.getId().toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    public void createTest() throws Exception {
        Book book = new Book();
        book.setTitle("Test Name");

        when(bookController.create(book)).thenReturn(book);

        mvc.perform(MockMvcRequestBuilders.post("/api/books")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated())
                .andExpect((ResultMatcher) jsonPath("$.name", is(book.getTitle())));
    }

    @Test
    public void removeUserById_whenDeleteMethod() throws Exception {
        Book book = new Book();
        book.setTitle("Test Name");
        book.setId(89L);

        doNothing().when(bookController).delete(book.getId());

        mvc.perform(delete("/api/books/" + book.getId().toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());
    }

    @Test
    public void should_throw_exception_when_user_doesnt_exist_when_delete() throws Exception {
        Book book = new Book();
        book.setId(89L);
        book.setTitle("Test Name");

        Mockito.doThrow(new UserNotFoundException()).when(bookController).delete(book.getId());

        mvc.perform(delete("/books/" + book.getId().toString())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());

    }
}