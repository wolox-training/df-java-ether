package wolox.training;

import com.google.common.base.Preconditions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThatThrownBy;

@SpringBootTest
class TrainingApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void givenNullString_whenCheckNotNullWithMessage_throwsException () {
		String nullObject = null;
		String message = "Please check the Object supplied, its null!";

		assertThatThrownBy(() -> Preconditions.checkNotNull(nullObject, message))
				.isInstanceOf(NullPointerException.class)
				.hasMessage(message).hasNoCause();
	}


}
